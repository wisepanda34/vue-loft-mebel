<template>
  <button class="btn" type="button"><slot></slot></button>
</template>

<script>
export default {
  name: "my-button"
}
</script>

<style lang="scss" scoped>

</style>