<template>
  <input type="text" class="input">
</template>

<script>
export default {
  name: "my-input"
}
</script>

<style lang="scss" scoped>
.input{
  background: #FCFCFC;
  box-shadow: inset 1px 1px 5px rgba(0, 0, 0, 0.07);
  border-radius: 4px;
  outline: none;
  border: none;
  padding: 0 10px;
}
</style>