<template>

  <h1>Page of the card</h1>

</template>

<script>

export default {
  name: "CardPage",
  components: {}
}
</script>

<style scoped>

</style>