<template>
<CartList/>
</template>

<script>

import CartList from "@/components/CartList.vue";

export default {
  name: "CartPage",
  components: {CartList,},
}
</script>

<style scoped>

</style>