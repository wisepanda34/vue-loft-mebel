<template>
  <Choose/>
</template>

<script>
import Header from "@/components/Header.vue";
import Footer from "@/components/Footer.vue";
import Choose from "@/components/Choose.vue";

export default {
  name: "Catalog",
  components: {Choose}
}
</script>

<style lang="scss" scoped>

</style>