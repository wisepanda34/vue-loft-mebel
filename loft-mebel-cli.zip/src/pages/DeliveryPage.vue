<template>
  <DeliveryOrder/>
</template>

<script>

import DeliveryOrder from "@/components/DeliveryOrder.vue";

export default {
  name: "DeliveryPage",
  components: {DeliveryOrder, }
}
</script>

<style lang="scss" scoped>

</style>