<template>

  <FavoritesList/>

</template>

<script>
import FavoritesList from "@/components/FavoritesList.vue";

export default {
  name: "FavoritesPage",
  components: {FavoritesList, }
}
</script>

<style scoped>

</style>